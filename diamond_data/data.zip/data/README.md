# Diamond phonon reference files for ml-peg-data

Add these four files to `diamond_data/data.zip`, next to `diamond.yaml`
(same layout as `ti64_data/data.zip`):

- `diamond_band_structure.npz` — DFT band structure (pickled phonopy-style dict)
- `diamond_thermal.json` — DFT Grüneisen / Debye / Slack-κ reference
- `diamond.xyz` — reference structure
- `diamond_qpath_metadata.pkl` — segmented q-points, labels, and path
  connections used to compute model band structures

`diamond.yaml` must stay in the zip (it provides the displacement dataset and
supercell metadata for the MLIP calculations). `dft_band.npz` and
`diamond_thermal_ref.json` are superseded by the converted files and can be
removed.

Provenance: converted from `dft_band.npz` (CASTEP/RSCAN, cm^-1) and
`diamond_thermal_ref.json` with ml-peg commit `9412105`
(`test_diamond_phonons_ref` + `_reference_band_path` in
`ml_peg/calcs/bulk_crystal/diamond_phonons/calc_diamond_phonons.py`, using
`qpath_distances` from `phonons_utils.py` for phonopy-convention band
distances).
